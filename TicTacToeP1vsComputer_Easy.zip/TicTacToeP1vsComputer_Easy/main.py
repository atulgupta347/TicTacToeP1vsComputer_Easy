#import
import pygame
import math
import random

#Initilaize
pygame.init()

#Images
X_IMAGE = pygame.transform.scale(pygame.image.load("Images/x.png"), (150, 150))
O_IMAGE = pygame.transform.scale(pygame.image.load("Images/o.png"), (150, 150))
icon=pygame.image.load("Images\icon.png")

#GameScreen
WIDTH=600
ROWS=3
win=pygame.display.set_mode((WIDTH,WIDTH))
pygame.display.set_caption("TicTacToe-Two Players Game")
pygame.display.set_icon(icon)

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 200, 0)
BLACK=(0, 0, 0)

# Fonts
END_FONT = pygame.font.SysFont('courier', 40)
AGAIN_FONT = pygame.font.SysFont('courier', 30)
BTN_FONT = pygame.font.SysFont('courier', 20)

#Initailize grid with centre positions
def initialize_grid():
    dis_to_cen = WIDTH // ROWS // 2

    # Initializing the array
    game_array = [[None, None, None], [None, None, None], [None, None, None]]

    for i in range(len(game_array)):
        for j in range(len(game_array[i])):
            x = dis_to_cen * (2 * j + 1)
            y = dis_to_cen * (2 * i + 1)

            # Adding centre coordinates
            game_array[i][j] = (x, y, "", True)

    return game_array

#Random position generation for Computer's turn
def computer_turn(game_array):
    computer_turn_over=False
    turn_left=["False"]
    while (True):
        r_x = random.randint(0, WIDTH)
        r_y = random.randint(0, WIDTH)
        for i in range(len(game_array)):
            for j in range(len(game_array[i])):
                x, y, char, can_play = game_array[i][j]
                dis = math.sqrt((x - r_x) ** 2 + (y - r_y) ** 2)
                turn_left.append(str(can_play))
                # If it's inside the square
                if dis < WIDTH // ROWS // 2 and can_play:
                    images.append((x, y, O_IMAGE))
                    x_turn = True
                    o_turn = False
                    game_array[i][j] = (x, y, 'o', False)
                    computer_turn_over=True

        if (computer_turn_over or not "True" in turn_left):
            break


#Update cordinates with turn's
def click(game_array):
    global x_turn, o_turn, images

    # Mouse position
    m_x, m_y = pygame.mouse.get_pos()

    for i in range(len(game_array)):
        for j in range(len(game_array[i])):
            x, y, char, can_play = game_array[i][j]
            # Distance between mouse and the centre of the square
            dis = math.sqrt((x - m_x) ** 2 + (y - m_y) ** 2)
            # If it's inside the square
            if dis < WIDTH // ROWS // 2 and can_play:
                images.append((x, y, X_IMAGE))
                x_turn = False
                o_turn = True
                game_array[i][j] = (x, y, 'x', False)
                break

    computer_turn(game_array)


#Draw grid with red line of width 4
def draw_grid():
    gap = WIDTH // ROWS

    # Starting points
    x = 0
    y = 0

    for i in range(ROWS+1):
        x = i * gap

        pygame.draw.line(win, BLACK, (x, 0), (x, WIDTH), 4)
        pygame.draw.line(win, BLACK, (0, x), (WIDTH, x), 4)

#Update grid with Image
def render():
    win.fill(WHITE)
    draw_grid()

    # Drawing X's and O's
    for image in images:
        x, y, IMAGE = image
        win.blit(IMAGE, (x - IMAGE.get_width() // 2, y - IMAGE.get_height() // 2))

    pygame.display.update()

#Check who is winner
def has_won(game_array):
    # Checking rows
    for row in range(len(game_array)):
        if (game_array[row][0][2] == game_array[row][1][2] == game_array[row][2][2]) and game_array[row][0][2] != "":
            display_message(game_array[row][0][2].upper() + " has won!")
            return True

    # Checking columns
    for col in range(len(game_array)):
        if (game_array[0][col][2] == game_array[1][col][2] == game_array[2][col][2]) and game_array[0][col][2] != "":
            display_message(game_array[0][col][2].upper() + " has won!")
            return True

    # Checking main diagonal
    if (game_array[0][0][2] == game_array[1][1][2] == game_array[2][2][2]) and game_array[0][0][2] != "":
        display_message(game_array[0][0][2].upper() + " has won!")
        return True

    # Checking reverse diagonal
    if (game_array[0][2][2] == game_array[1][1][2] == game_array[2][0][2]) and game_array[0][2][2] != "":
        display_message(game_array[0][2][2].upper() + " has won!")
        return True

    return False

#Display message and wait for 3secs
def display_message(content):
    pygame.time.delay(500)
    win.fill(WHITE)
    end_text = END_FONT.render(content, True, GREEN)
    win.blit(end_text, ((WIDTH - end_text.get_width()) // 2, (WIDTH - end_text.get_height()) // 2))
    pygame.display.update()
    pygame.time.delay(3000)

#Check any grid is empty
def has_drawn(game_array):
    for i in range(len(game_array)):
        for j in range(len(game_array[i])):
            if game_array[i][j][2] == "":
                return False

    display_message("It's a draw!")
    return True

#Main function
def main():
    global x_turn, o_turn, images, draw, quit
    images = []
    draw = False
    run = True
    x_turn = True
    o_turn = False
    quit=False
    game_array = initialize_grid()

    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit=True
                pygame.quit()
                break
            elif event.type == pygame.MOUSEBUTTONDOWN:
                click(game_array)
        if quit:
            break

        render()
        if has_won(game_array) or has_drawn(game_array):
            run = False
    return quit
#Check Button Yes or No
def CheckBtnClick():
    b_x, b_y = pygame.mouse.get_pos()
    if 100 <= b_x <= 200 and 350 < b_y <= 380:
        return True
    elif 400 <= b_x <= 500 and 350 < b_y <= 380:
        return False
    else:
        return CheckWantToPlay()

#Check Play Again
def CheckWantToPlay():
    win.fill(WHITE)
    end_text = AGAIN_FONT.render("Do you want to Play again?", True, BLUE)
    win.blit(end_text, ((WIDTH - end_text.get_width()) // 2, (WIDTH - end_text.get_height()) // 2))
    Yestext = BTN_FONT.render('Yes', True, GREEN)
    Notext = BTN_FONT.render('No', True, RED)
    pygame.draw.rect(win,BLACK,[100,350 ,100,30],2)
    pygame.draw.rect(win, BLACK, [400, 350, 100, 30],2)
    win.blit(Yestext, (130,355))
    win.blit(Notext, (440,355))
    pygame.display.update()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                return CheckBtnClick()
#start
WantToPlay=True
while WantToPlay:
    if __name__ == '__main__':
        userquit=main()
        pygame.time.delay(3000)
        if not userquit:
            WantToPlay=CheckWantToPlay()
        else:
            WantToPlay=False
        if WantToPlay==False:
            pygame.quit()